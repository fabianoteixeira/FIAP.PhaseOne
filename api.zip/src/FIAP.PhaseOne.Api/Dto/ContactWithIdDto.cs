﻿namespace FIAP.PhaseOne.Api.Dto;

public class ContactWithIdDto : ContactDto
{
    public Guid Id { get; set; }
}
