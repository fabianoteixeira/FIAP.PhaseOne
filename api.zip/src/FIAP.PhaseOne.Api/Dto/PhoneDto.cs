﻿namespace FIAP.PhaseOne.Api.Dto;

public class PhoneDto
{
    public int DDD { get; set; }
    public string Number { get; set; }
}
