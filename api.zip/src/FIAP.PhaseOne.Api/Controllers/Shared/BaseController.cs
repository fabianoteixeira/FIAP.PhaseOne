﻿using Microsoft.AspNetCore.Mvc;

namespace FIAP.PhaseOne.Api.Controllers.Shared
{
    [ApiController]
    public abstract class BaseController : ControllerBase
    {
    }
}
