﻿namespace FIAP.PhaseOne.Application.Dto;

public class PhoneDto
{
    public int DDD { get; set; }
    public string Number { get; set; }
}
