﻿namespace FIAP.PhaseOne.Application.Dto;

public class ContactWithIdDto : ContactDto
{
    public Guid Id { get; set; }
}
