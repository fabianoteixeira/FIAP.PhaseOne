﻿namespace FIAP.PhaseOne.Application.Handlers.Commands.AddContact;

public class AddContactResponse
{
    public Guid Id { get; set; }
}
