﻿global using MediatR;
global using ErrorOr;
global using FIAP.PhaseOne.Application.Shared;
